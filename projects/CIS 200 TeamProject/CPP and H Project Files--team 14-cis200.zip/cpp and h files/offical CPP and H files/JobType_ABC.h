//JOB TYPE CLASS HEADER FILE 
//this struct is meant to be bear bones to simply store some data 
//CPP file likely not needed/not expected to be needed

#ifndef JOBTYPE_ABC_H
#define JOBTYPE_ABC_H



struct JobType_ABC
{
	char jobType;
	int arrivalTime;
	int processingTime;
	
	


};





#endif
